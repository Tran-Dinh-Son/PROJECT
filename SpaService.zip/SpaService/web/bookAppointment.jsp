<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book an Appointment - Your App Name</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Nunito', 'sans-serif'],
                    },
                    colors: {
                        primary: '#3B82F6',
                        secondary: '#60A5FA',
                    },
                }
            }
        }
    </script>
</head>
<body class="bg-gradient-to-r from-blue-100 to-blue-200 min-h-screen flex items-center justify-center p-4">
    <div class="bg-white w-full max-w-md rounded-2xl shadow-xl overflow-hidden">
        <div class="p-8">
            <h2 class="text-3xl font-bold text-center mb-8 text-primary">Book an Appointment</h2>
            <form action="MainController" method="post" class="space-y-6">
                <input type="hidden" name="action" value="BookAppointment">
                <div>
                    <label for="serviceID" class="text-sm font-medium text-gray-600 block mb-1">Select Service:</label>
                    <select name="serviceID" required
                            class="w-full px-4 py-3 rounded-lg bg-blue-50 border-transparent focus:border-primary focus:ring-2 focus:ring-primary focus:bg-white text-sm transition duration-300">
                        <c:forEach var="service" items="${services}">
                            <option value="${service.serviceID}">${service.serviceName} - $${service.price}</option>
                        </c:forEach>
                    </select>
                </div>
                <div>
                    <label for="appointmentDate" class="text-sm font-medium text-gray-600 block mb-1">Appointment Date:</label>
                    <input type="datetime-local" name="appointmentDate" required
                           class="w-full px-4 py-3 rounded-lg bg-blue-50 border-transparent focus:border-primary focus:ring-2 focus:ring-primary focus:bg-white text-sm transition duration-300">
                </div>
                <button type="submit" 
                        class="w-full py-3 font-semibold rounded-lg bg-primary text-white hover:bg-secondary transition duration-300 transform hover:scale-105">
                    Book Appointment
                </button>
            </form>
            <c:if test="${not empty ERROR}">
                <p class="mt-4 text-red-500 text-center text-sm font-medium bg-red-100 py-2 rounded-lg">${ERROR}</p>
            </c:if>
        </div>
    </div>
</body>
</html>