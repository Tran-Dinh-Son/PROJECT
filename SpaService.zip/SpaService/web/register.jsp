<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Your App Name</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Nunito', 'sans-serif'],
                    },
                    colors: {
                        primary: '#3B82F6',
                        secondary: '#60A5FA',
                    },
                }
            }
        }
    </script>
</head>
<body class="bg-gradient-to-r from-blue-100 to-blue-200 min-h-screen flex items-center justify-center p-4">
    <div class="bg-white w-full max-w-md rounded-2xl shadow-xl overflow-hidden">
        <div class="p-8">
            <h2 class="text-3xl font-bold text-center mb-8 text-primary">Join Us</h2>
            <form action="MainController" method="post" class="space-y-4">
                <div>
                    <label for="userId" class="text-sm font-medium text-gray-600 block mb-1">User ID</label>
                    <input type="text" id="userId" name="userId" required
                           class="w-full px-4 py-3 rounded-lg bg-blue-50 border-transparent focus:border-primary focus:ring-2 focus:ring-primary focus:bg-white text-sm transition duration-300">
                </div>
                <div>
                    <label for="fullName" class="text-sm font-medium text-gray-600 block mb-1">Full Name</label>
                    <input type="text" id="fullName" name="fullName" required
                           class="w-full px-4 py-3 rounded-lg bg-blue-50 border-transparent focus:border-primary focus:ring-2 focus:ring-primary focus:bg-white text-sm transition duration-300">
                </div>
                <div>
                    <label for="email" class="text-sm font-medium text-gray-600 block mb-1">Email</label>
                    <input type="email" id="email" name="email" required
                           class="w-full px-4 py-3 rounded-lg bg-blue-50 border-transparent focus:border-primary focus:ring-2 focus:ring-primary focus:bg-white text-sm transition duration-300">
                </div>
                <div>
                    <label for="phoneNumber" class="text-sm font-medium text-gray-600 block mb-1">Phone Number</label>
                    <input type="text" id="phoneNumber" name="phoneNumber" required
                           class="w-full px-4 py-3 rounded-lg bg-blue-50 border-transparent focus:border-primary focus:ring-2 focus:ring-primary focus:bg-white text-sm transition duration-300">
                </div>
                <div>
                    <label for="password" class="text-sm font-medium text-gray-600 block mb-1">Password</label>
                    <input type="password" id="password" name="password" required
                           class="w-full px-4 py-3 rounded-lg bg-blue-50 border-transparent focus:border-primary focus:ring-2 focus:ring-primary focus:bg-white text-sm transition duration-300">
                </div>
                <input type="hidden" name="action" value="Login">
                <input type="hidden" name="function" value="register">
                <button type="submit" 
                        class="w-full py-3 font-semibold rounded-lg bg-primary text-white hover:bg-secondary transition duration-300 transform hover:scale-105">
                    Create Account
                </button>
            </form>
            <p class="text-center mt-6 text-sm text-gray-600">
                Already have an account? <a href="login.jsp" class="font-semibold text-primary hover:text-secondary transition duration-300">Sign In</a>
            </p>
        </div>
    </div>
</body>
</html>