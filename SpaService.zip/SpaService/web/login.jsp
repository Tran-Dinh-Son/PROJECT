<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Your App Name</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Nunito', 'sans-serif'],
                    },
                    colors: {
                        primary: '#3B82F6',
                        secondary: '#60A5FA',
                    },
                }
            }
        }
    </script>
</head>
<body class="bg-gradient-to-r from-blue-100 to-blue-200 min-h-screen flex items-center justify-center p-4">
    <div class="bg-white w-full max-w-md rounded-2xl shadow-xl overflow-hidden">
        <div class="p-8">
            <h2 class="text-3xl font-bold text-center mb-8 text-primary">Welcome Back</h2>
            <form action="MainController" method="post" class="space-y-6">
                <div>
                    <label for="userId" class="text-sm font-medium text-gray-600 block mb-1">User ID</label>
                    <input type="text" id="userId" name="userId" required
                           class="w-full px-4 py-3 rounded-lg bg-blue-50 border-transparent focus:border-primary focus:ring-2 focus:ring-primary focus:bg-white text-sm transition duration-300">
                </div>
                <div>
                    <label for="password" class="text-sm font-medium text-gray-600 block mb-1">Password</label>
                    <input type="password" id="password" name="password" required
                           class="w-full px-4 py-3 rounded-lg bg-blue-50 border-transparent focus:border-primary focus:ring-2 focus:ring-primary focus:bg-white text-sm transition duration-300">
                </div>
                <input type="hidden" name="action" value="Login">
                <input type="hidden" name="function" value="login">
                <button type="submit" 
                        class="w-full py-3 font-semibold rounded-lg bg-primary text-white hover:bg-secondary transition duration-300 transform hover:scale-105">
                    Sign In
                </button>
            </form>
            <p class="text-center mt-8 text-sm text-gray-600">
                Don't have an account? <a href="register.jsp" class="font-semibold text-primary hover:text-secondary transition duration-300">Create one</a>
            </p>
            <% String error = request.getParameter("error");
               if ("invalid".equals(error)) { %>
                <p class="text-red-500 text-center mt-4 text-sm font-medium bg-red-100 py-2 rounded-lg">Invalid username or password</p>
            <% } %>
        </div>
    </div>
</body>
</html>