<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Appointments - Your App Name</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Nunito', 'sans-serif'],
                    },
                    colors: {
                        primary: '#3B82F6',
                        secondary: '#60A5FA',
                    },
                }
            }
        }
    </script>
</head>
<body class="bg-gradient-to-r from-blue-100 to-blue-200 min-h-screen p-4">
    <div class="container mx-auto">
        <div class="bg-white rounded-2xl shadow-xl overflow-hidden max-w-4xl mx-auto">
            <div class="p-8">
                <h2 class="text-3xl font-bold text-center mb-8 text-primary">Your Appointments</h2>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-blue-500">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase tracking-wider">Appointment ID</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase tracking-wider">Service</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase tracking-wider">Date</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase tracking-wider">Status</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <c:forEach var="appointment" items="${appointments}">
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap">${appointment.appointmentID}</td>
                                    <td class="px-6 py-4 whitespace-nowrap">${appointment.serviceID}</td>
                                    <td class="px-6 py-4 whitespace-nowrap">${appointment.appointmentDate}</td>
                                    <td class="px-6 py-4 whitespace-nowrap">${appointment.status}</td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <form action="CancelAppointmentController" method="post">
                                            <input type="hidden" name="appointmentID" value="${appointment.appointmentID}">
                                            <button type="submit" class="text-red-600 hover:text-red-900 font-medium">Cancel</button>
                                        </form>
                                    </td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                </div>
                <div class="mt-8 text-center">
                    <a href="dashboard.jsp" class="inline-block bg-primary text-white font-semibold py-2 px-4 rounded-lg hover:bg-secondary transition duration-300">Back to Dashboard</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>