<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Your App Name</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Nunito', 'sans-serif'],
                    },
                    colors: {
                        primary: '#3B82F6',
                        secondary: '#60A5FA',
                    },
                }
            }
        }
    </script>
</head>
<body class="bg-gradient-to-r from-blue-100 to-blue-200 min-h-screen">
    <c:choose>
        <c:when test="${empty sessionScope.userID}">
            <c:redirect url="login.jsp" />
        </c:when>
        <c:otherwise>
            <div class="container mx-auto px-4 py-8">
                <div class="bg-white rounded-2xl shadow-xl overflow-hidden max-w-4xl mx-auto">
                    <div class="p-8">
                        <h2 class="text-3xl font-bold text-primary mb-6">Welcome, ${sessionScope.fullName}!</h2>
                        <nav class="mb-8">
                            <ul class="space-y-2">
                                <c:choose>
                                    <c:when test="${sessionScope.roleID == 'ADM'}">
                                        <li><a href="createService.jsp" class="block px-4 py-2 rounded-lg bg-blue-100 text-primary hover:bg-blue-200 transition duration-300">Create Service</a></li>
                                        <li><a href="ViewServicesController" class="block px-4 py-2 rounded-lg bg-blue-100 text-primary hover:bg-blue-200 transition duration-300">Manage Services</a></li>
                                    </c:when>
                                    <c:when test="${sessionScope.roleID == 'STF'}">
                                        <li><a href="MainController?action=ViewConsultation" class="block px-4 py-2 rounded-lg bg-blue-100 text-primary hover:bg-blue-200 transition duration-300">View Consultations</a></li>
                                    </c:when>
                                    <c:when test="${sessionScope.roleID == 'USR'}">
                                        <li><a href="MainController?action=BookAppointment" class="block px-4 py-2 rounded-lg bg-blue-100 text-primary hover:bg-blue-200 transition duration-300">Book an Appointment</a></li>
                                        <li><a href="ViewAppointmentsController" class="block px-4 py-2 rounded-lg bg-blue-100 text-primary hover:bg-blue-200 transition duration-300">View Appointments</a></li>
                                        <li><a href="MainController?action=ReviewService" class="block px-4 py-2 rounded-lg bg-blue-100 text-primary hover:bg-blue-200 transition duration-300">Review a Service</a></li>
                                    </c:when>
                                </c:choose>
                                <li><a href="MainController?action=Login&function=logout" class="block px-4 py-2 rounded-lg bg-red-100 text-red-600 hover:bg-red-200 transition duration-300">Logout</a></li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </c:otherwise>
    </c:choose>
</body>
</html>