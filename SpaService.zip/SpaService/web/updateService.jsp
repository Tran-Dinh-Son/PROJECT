<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Service</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Nunito', 'sans-serif'],
                    },
                    colors: {
                        primary: '#3B82F6',
                        secondary: '#60A5FA',
                    },
                }
            }
        }
    </script>
</head>
<body class="bg-gradient-to-r from-blue-100 to-blue-200 min-h-screen flex items-center justify-center p-4">
    <div class="bg-white w-full max-w-lg rounded-2xl shadow-xl p-8">
        <h2 class="text-3xl font-bold text-center mb-8 text-primary">Update Service</h2>
        
        <form action="UpdateServiceController" method="post" class="space-y-6">
            <input type="hidden" name="action" value="UpdateService">
            <input type="hidden" name="serviceID" value="${services.serviceID}">

            <div>
                <label for="serviceName" class="text-sm font-medium text-gray-600 block mb-1">Service Name:</label>
                <input type="text" name="serviceName" value="${services.serviceName}" required
                       class="w-full px-4 py-3 rounded-lg bg-blue-50 border-transparent focus:border-primary focus:ring-2 focus:ring-primary focus:bg-white text-sm transition duration-300">
            </div>

            <div>
                <label for="description" class="text-sm font-medium text-gray-600 block mb-1">Description:</label>
                <textarea name="description" rows="5" required
                          class="w-full px-4 py-3 rounded-lg bg-blue-50 border-transparent focus:border-primary focus:ring-2 focus:ring-primary focus:bg-white text-sm transition duration-300">${services.description}</textarea>
            </div>

            <div>
                <label for="price" class="text-sm font-medium text-gray-600 block mb-1">Price:</label>
                <input type="number" step="0.01" name="price" value="${services.price}" required
                       class="w-full px-4 py-3 rounded-lg bg-blue-50 border-transparent focus:border-primary focus:ring-2 focus:ring-primary focus:bg-white text-sm transition duration-300">
            </div>

            <button type="submit" 
                    class="w-full py-3 font-semibold rounded-lg bg-primary text-white hover:bg-secondary transition duration-300 transform hover:scale-105">
                Update Service
            </button>
        </form>

        <div class="mt-6 text-center">
            <a href="dashboard.jsp" class="text-primary hover:underline">Back to Dashboard</a>
        </div>
    </div>
</body>
</html>
