package Controller;

import Model.DiscountCodeDao;
import Model.DiscountCodeDto;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DiscountCodeController extends HttpServlet {

    private DiscountCodeDao discountCodeDao = new DiscountCodeDao();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("list".equals(action)) {
            listAllDiscountCodes(request, response);
        } else if ("delete".equals(action)) {
            deleteDiscountCode(request, response);
        } else if ("getById".equals(action)) {
            getDiscountCodeById(request, response);
        } else if ("search".equals(action)) {
            searchDiscountCodes(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("createOrUpdate".equals(action)) {
            createOrUpdateDiscountCode(request, response);
        }
    }

    private void listAllDiscountCodes(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<DiscountCodeDto> discountCodes = discountCodeDao.listAllDiscountCodes();
        request.setAttribute("discountCodes", discountCodes);
        request.getRequestDispatcher("DiscountCodeList.jsp").forward(request, response);
    }

    private void createOrUpdateDiscountCode(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String discountIdStr = request.getParameter("discountId");
        Integer discountId = (discountIdStr != null && !discountIdStr.isEmpty()) ? Integer.parseInt(discountIdStr) : null;
        String code = request.getParameter("code");
        double discountPercent = Double.parseDouble(request.getParameter("discountPercent"));
        String status = request.getParameter("status");
        String createdBy = (String) request.getSession().getAttribute("username");

        DiscountCodeDto discountCode = new DiscountCodeDto(discountId, code, discountPercent, status, createdBy, null);
        boolean success = discountCodeDao.saveDiscountCode(discountCode);

        if (success) {
            response.sendRedirect("DiscountCodeController?action=list");
        } else {
            request.setAttribute("error", "Failed to save discount code.");
            request.getRequestDispatcher("DiscountCodeForm.jsp").forward(request, response);
        }
    }

    private void deleteDiscountCode(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int discountId = Integer.parseInt(request.getParameter("discountId"));
        discountCodeDao.deleteDiscountCode(discountId);
        response.sendRedirect("DiscountCodeController?action=list");
    }

    private void getDiscountCodeById(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int discountId = Integer.parseInt(request.getParameter("discountId"));
        DiscountCodeDto discountCode = discountCodeDao.getDiscountCodeById(discountId);

        if (discountCode != null) {
            request.setAttribute("discountCode", discountCode);
            request.getRequestDispatcher("DiscountCodeForm.jsp").forward(request, response);
        } else {
            response.sendRedirect("DiscountCodeController?action=list");
        }
    }

// Tìm kiếm mã giảm giá theo code và status
    private void searchDiscountCodes(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String code = request.getParameter("code");
        String status = request.getParameter("status");

        List<DiscountCodeDto> discountCodes = discountCodeDao.searchDiscountCodes(code, status);
        request.setAttribute("discountCodes", discountCodes);
        request.getRequestDispatcher("DiscountCodeList.jsp").forward(request, response);
    }
}
