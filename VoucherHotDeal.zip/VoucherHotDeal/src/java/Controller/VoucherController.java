package Controller;

import Model.VoucherDao;
import Model.VoucherDto;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class VoucherController extends HttpServlet {

    private VoucherDao voucherDao = new VoucherDao();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("list".equals(action)) {
            listAllVouchers(request, response);
        } else if ("getById".equals(action)) {
            getVoucherById(request, response);
        } else if ("delete".equals(action)) {
            deleteVoucher(request, response);
        } else if ("search".equals(action)) {
            searchVouchers(request, response);
        } else if ("changeStatus".equals(action)) {
            changeVoucherStatus(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("createOrUpdate".equals(action)) {
            createOrUpdateVoucher(request, response);
        }
    }

    private void listAllVouchers(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<VoucherDto> vouchers = voucherDao.listAllVouchers();
        request.setAttribute("vouchers", vouchers);
        request.getRequestDispatcher("VoucherList.jsp").forward(request, response);
    }

    private void getVoucherById(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("voucherId"));
        VoucherDto voucher = voucherDao.getVoucherById(id);
        request.setAttribute("voucher", voucher);
        request.getRequestDispatcher("VoucherForm.jsp").forward(request, response);
    }

    private void createOrUpdateVoucher(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String voucherIdStr = request.getParameter("voucherId");
        Integer id = (voucherIdStr != null && !voucherIdStr.isEmpty()) ? Integer.parseInt(voucherIdStr) : 0;

        String code = request.getParameter("voucherCode");
        String description = request.getParameter("description");
        double discount = Double.parseDouble(request.getParameter("discountPercent"));
        String category = request.getParameter("category");
        String status = request.getParameter("status");

        VoucherDto voucher = new VoucherDto(id, code, description, discount, category, status);

        boolean success = voucherDao.saveVoucher(voucher);

        if (success) {
            response.sendRedirect("VoucherController?action=list");
        } else {
            request.setAttribute("error", "Unable to save voucher");
            request.getRequestDispatcher("VoucherForm.jsp").forward(request, response);
        }
    }

    private void deleteVoucher(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("voucherId"));
        boolean success = voucherDao.deleteVoucher(id);
        response.sendRedirect("VoucherController?action=list");
    }

    private void changeVoucherStatus(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("voucherId"));
        boolean success = voucherDao.setInactive(id);
        response.sendRedirect("VoucherController?action=list");
    }

    private void searchVouchers(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String category = request.getParameter("category");
        String status = request.getParameter("status");
        if ((category == null || category.isEmpty()) && (status == null || status.isEmpty())) {
            category = null;
            status = null;
        }
        List<VoucherDto> vouchers = voucherDao.searchVouchers(category, status);
        request.setAttribute("vouchers", vouchers);
        request.getRequestDispatcher("VoucherList.jsp").forward(request, response);
    }
}
