package Controller;

import Model.PromotionDao;
import Model.PromotionDto;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class PromotionController extends HttpServlet {
    private PromotionDao promotionDao = new PromotionDao();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("list".equals(action)) {
            listAllPromotions(request, response);
        } else if ("getById".equals(action)) {
            getPromotionById(request, response);
        } else if ("delete".equals(action)) {
            deletePromotion(request, response);
        } else if ("search".equals(action)) {
            searchPromotions(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        savePromotion(request, response);
    }

    private void listAllPromotions(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<PromotionDto> promotions = promotionDao.listAllPromotions();
        request.setAttribute("promotions", promotions);
        request.getRequestDispatcher("PromotionList.jsp").forward(request, response);
    }

    private void getPromotionById(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int promotionId = Integer.parseInt(request.getParameter("promotionId"));
        PromotionDto promotion = promotionDao.getPromotionById(promotionId);

        if (promotion != null) {
            request.setAttribute("promotion", promotion);
            request.getRequestDispatcher("PromotionForm.jsp").forward(request, response);
        } else {
            response.sendRedirect("PromotionController?action=list");
        }
    }

    private void savePromotion(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String promotionIdStr = request.getParameter("promotionId");
        Integer promotionId = (promotionIdStr != null && !promotionIdStr.isEmpty()) ? Integer.parseInt(promotionIdStr) : null;
        String promotionName = request.getParameter("promotionName");
        String description = request.getParameter("description");
        Integer voucherId = (request.getParameter("voucherId") != null && !request.getParameter("voucherId").isEmpty()) ? Integer.parseInt(request.getParameter("voucherId")) : null;
        Integer dealId = (request.getParameter("dealId") != null && !request.getParameter("dealId").isEmpty()) ? Integer.parseInt(request.getParameter("dealId")) : null;
        Integer discountId = (request.getParameter("discountId") != null && !request.getParameter("discountId").isEmpty()) ? Integer.parseInt(request.getParameter("discountId")) : null;
        String startDate = request.getParameter("startDate");
        String endDate = request.getParameter("endDate");
        String status = request.getParameter("status");

        PromotionDto promotion = new PromotionDto(promotionId, promotionName, description, voucherId, dealId, discountId, startDate, endDate, status);
        boolean success = promotionDao.savePromotion(promotion);

        if (success) {
            response.sendRedirect("PromotionController?action=list");
        } else {
            request.setAttribute("error", "Failed to save promotion.");
            request.getRequestDispatcher("PromotionForm.jsp").forward(request, response);
        }
    }

    private void deletePromotion(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int promotionId = Integer.parseInt(request.getParameter("promotionId"));
        promotionDao.deletePromotion(promotionId);
        response.sendRedirect("PromotionController?action=list");
    }

    private void searchPromotions(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String promotionName = request.getParameter("promotionName");
        String status = request.getParameter("status");
        Integer voucherId = (request.getParameter("voucherId") != null && !request.getParameter("voucherId").isEmpty()) ? Integer.parseInt(request.getParameter("voucherId")) : null;
        Integer dealId = (request.getParameter("dealId") != null && !request.getParameter("dealId").isEmpty()) ? Integer.parseInt(request.getParameter("dealId")) : null;
        Integer discountId = (request.getParameter("discountId") != null && !request.getParameter("discountId").isEmpty()) ? Integer.parseInt(request.getParameter("discountId")) : null;

        List<PromotionDto> promotions = promotionDao.searchPromotions(promotionName, status, voucherId, dealId, discountId);
        request.setAttribute("promotions", promotions);
        request.getRequestDispatcher("PromotionList.jsp").forward(request, response);
    }
}
