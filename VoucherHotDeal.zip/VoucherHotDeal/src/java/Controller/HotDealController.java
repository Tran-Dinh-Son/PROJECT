package Controller;

import Model.HotDealDao;
import Model.HotDealDto;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class HotDealController extends HttpServlet {

    private HotDealDao hotDealDao = new HotDealDao();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("list".equals(action)) {
            listAllHotDeals(request, response);
        } else if ("getById".equals(action)) {
            getHotDealById(request, response);
        } else if ("delete".equals(action)) {
            deleteHotDeal(request, response);
        } else if ("search".equals(action)) {
            searchHotDeals(request, response);
        } else if ("changeStatus".equals(action)) {
            changeHotDealStatus(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("createOrUpdate".equals(action)) {
            createOrUpdateHotDeal(request, response);
        }
    }

    private void listAllHotDeals(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<HotDealDto> hotDeals = hotDealDao.listAllHotDeals();
        request.setAttribute("hotDeals", hotDeals);
        request.getRequestDispatcher("HotDealList.jsp").forward(request, response);
    }

    private void getHotDealById(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("dealId"));
        HotDealDto hotDeal = hotDealDao.getHotDealById(id);
        request.setAttribute("hotDeal", hotDeal);
        request.getRequestDispatcher("HotDealForm.jsp").forward(request, response);
    }

    private void createOrUpdateHotDeal(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String dealId = request.getParameter("dealId");
        int id = (dealId != null && !dealId.isEmpty()) ? Integer.parseInt(dealId) : 0;
        String name = request.getParameter("dealName");
        String description = request.getParameter("description");
        double discount = Double.parseDouble(request.getParameter("discountAmount"));
        String category = request.getParameter("category");
        String status = request.getParameter("status");
        String expirationDate = request.getParameter("expirationDate");

        HotDealDto hotDeal = new HotDealDto(id, name, description, discount, category, status, expirationDate);
        boolean success = hotDealDao.saveHotDeal(hotDeal);

        if (success) {
            response.sendRedirect("HotDealController?action=list");
        } else {
            request.setAttribute("error", "Unable to save hot deal");
            request.getRequestDispatcher("HotDealForm.jsp").forward(request, response);
        }
    }

    private void deleteHotDeal(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("dealId"));
        boolean success = hotDealDao.deleteHotDeal(id);
        response.sendRedirect("HotDealController?action=list");
    }

    private void changeHotDealStatus(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("dealId"));
        boolean success = hotDealDao.setInactive(id);
        response.sendRedirect("HotDealController?action=list");
    }

    private void searchHotDeals(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String category = request.getParameter("category");
        String status = request.getParameter("status");
        if ((category == null || category.isEmpty()) && (status == null || status.isEmpty())) {
            category = null;
            status = null;
        }
        List<HotDealDto> hotDeals = hotDealDao.searchHotDeals(category, status);
        request.setAttribute("hotDeals", hotDeals);
        request.getRequestDispatcher("HotDealList.jsp").forward(request, response);
    }
}
