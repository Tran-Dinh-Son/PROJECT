package Model;

import Utils.DBUtils;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class HotDealDao extends DBUtils {
    
    // Search Hot Deals by Category or Status
    public List<HotDealDto> searchHotDeals(String category, String status) {
    List<HotDealDto> hotDeals = new ArrayList<>();
    
    // Xây dựng SQL động
    String query = "SELECT * FROM tblHotDeals WHERE 1=1";
    List<String> params = new ArrayList<>();
    
    if (category != null && !category.isEmpty()) {
        query += " AND Category = ?";
        params.add(category);
    }
    if (status != null && !status.isEmpty()) {
        query += " AND Status = ?";
        params.add(status);
    }
    
    try (Connection connection = DBUtils.getConnection();
         PreparedStatement statement = connection.prepareStatement(query)) {
        
        // Gán tham số vào câu lệnh SQL
        for (int i = 0; i < params.size(); i++) {
            statement.setString(i + 1, params.get(i));
        }
        
        ResultSet resultSet = statement.executeQuery();
        
        while (resultSet.next()) {
            hotDeals.add(new HotDealDto(
                    resultSet.getInt("deal_id"),
                    resultSet.getString("deal_name"),
                    resultSet.getString("Description"),
                    resultSet.getDouble("discount_amount"),
                    resultSet.getString("Category"),
                    resultSet.getString("Status"),
                    resultSet.getString("expiration_date")
            ));
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
    }
    return hotDeals;
}

    
    // Create or Update Hot Deal
    public boolean saveHotDeal(HotDealDto hotDeal) {
        String query = hotDeal.getDealId() > 0 ?
                "UPDATE tblHotDeals SET deal_name = ?, Description = ?, discount_amount = ?, Category = ?, Status = ?, expiration_date = ? WHERE deal_id = ?" :
                "INSERT INTO tblHotDeals (deal_name, Description, discount_amount, Category, Status, expiration_date) VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection connection = DBUtils.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            
            statement.setString(1, hotDeal.getDealName());
            statement.setString(2, hotDeal.getDescription());
            statement.setDouble(3, hotDeal.getDiscountAmount());
            statement.setString(4, hotDeal.getCategory());
            statement.setString(5, hotDeal.getStatus());
            statement.setString(6, hotDeal.getExpirationDate());
            
            if (hotDeal.getDealId() > 0) {
                statement.setInt(7, hotDeal.getDealId());
            }
            
            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
    
    // Change Status to Inactive
    public boolean setInactive(int dealId) {
        String query = "UPDATE tblHotDeals SET Status = 'Inactive' WHERE deal_id = ?";
        try (Connection connection = DBUtils.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            
            statement.setInt(1, dealId);
            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
    
    // List all Hot Deals
    public List<HotDealDto> listAllHotDeals() {
        List<HotDealDto> hotDeals = new ArrayList<>();
        String query = "SELECT * FROM tblHotDeals";
        try (Connection connection = DBUtils.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {
            
            while (resultSet.next()) {
                hotDeals.add(new HotDealDto(
                        resultSet.getInt("deal_id"),
                        resultSet.getString("deal_name"),
                        resultSet.getString("Description"),
                        resultSet.getDouble("discount_amount"),
                        resultSet.getString("Category"),
                        resultSet.getString("Status"),
                        resultSet.getString("expiration_date")
                ));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return hotDeals;
    }
    
    // Get Hot Deal by ID
    public HotDealDto getHotDealById(int dealId) {
        String query = "SELECT * FROM tblHotDeals WHERE deal_id = ?";
        try (Connection connection = DBUtils.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            
            statement.setInt(1, dealId);
            ResultSet resultSet = statement.executeQuery();
            
            if (resultSet.next()) {
                return new HotDealDto(
                        resultSet.getInt("deal_id"),
                        resultSet.getString("deal_name"),
                        resultSet.getString("Description"),
                        resultSet.getDouble("discount_amount"),
                        resultSet.getString("Category"),
                        resultSet.getString("Status"),
                        resultSet.getString("expiration_date")
                );
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }
    
    // Delete Hot Deal
    public boolean deleteHotDeal(int dealId) {
        String query = "DELETE FROM tblHotDeals WHERE deal_id = ?";
        try (Connection connection = DBUtils.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            
            statement.setInt(1, dealId);
            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
}