/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author ADMIN
 */
public class HotDealDto {
    private int dealId;
    private String dealName;
    private String description;
    private double discountAmount;
    private String category;
    private String status;
    private String expirationDate;

    public HotDealDto() {
    }

    public HotDealDto(int dealId, String dealName, String description, double discountAmount, String category, String status, String expirationDate) {
        this.dealId = dealId;
        this.dealName = dealName;
        this.description = description;
        this.discountAmount = discountAmount;
        this.category = category;
        this.status = status;
        this.expirationDate = expirationDate;
    }

    public int getDealId() {
        return dealId;
    }

    public void setDealId(int dealId) {
        this.dealId = dealId;
    }

    public String getDealName() {
        return dealName;
    }

    public void setDealName(String dealName) {
        this.dealName = dealName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getDiscountAmount() {
        return discountAmount;
    }

    public void setDiscountAmount(double discountAmount) {
        this.discountAmount = discountAmount;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }
    
    
}
