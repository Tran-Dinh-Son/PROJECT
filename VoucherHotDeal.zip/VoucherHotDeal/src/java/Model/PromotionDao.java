package Model;

import Utils.DBUtils;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PromotionDao extends DBUtils {

    // Lấy danh sách tất cả chương trình khuyến mãi
    public List<PromotionDto> listAllPromotions() {
        List<PromotionDto> promotions = new ArrayList<>();
        String query = "SELECT * FROM tblPromotions";

        try (Connection connection = DBUtils.getConnection();
             PreparedStatement statement = connection.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                promotions.add(new PromotionDto(
                        resultSet.getInt("promotion_id"),
                        resultSet.getString("promotion_name"),
                        resultSet.getString("description"),
                        resultSet.getInt("voucher_id"),
                        resultSet.getInt("deal_id"),
                        resultSet.getInt("discount_id"),
                        resultSet.getString("start_date"),
                        resultSet.getString("end_date"),
                        resultSet.getString("status")
                ));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return promotions;
    }

    // Tìm kiếm chương trình khuyến mãi theo các tiêu chí
    public List<PromotionDto> searchPromotions(String promotionName, String status, Integer voucherId, Integer dealId, Integer discountId) {
        List<PromotionDto> promotions = new ArrayList<>();
        String query = "SELECT * FROM tblPromotions WHERE 1=1";
        List<Object> params = new ArrayList<>();

        if (promotionName != null && !promotionName.isEmpty()) {
            query += " AND promotion_name LIKE ?";
            params.add("%" + promotionName + "%");
        }
        if (status != null && !status.isEmpty()) {
            query += " AND status = ?";
            params.add(status);
        }
        if (voucherId != null) {
            query += " AND voucher_id = ?";
            params.add(voucherId);
        }
        if (dealId != null) {
            query += " AND deal_id = ?";
            params.add(dealId);
        }
        if (discountId != null) {
            query += " AND discount_id = ?";
            params.add(discountId);
        }

        try (Connection connection = DBUtils.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            
            for (int i = 0; i < params.size(); i++) {
                if (params.get(i) instanceof String) {
                    statement.setString(i + 1, (String) params.get(i));
                } else {
                    statement.setInt(i + 1, (Integer) params.get(i));
                }
            }

            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                promotions.add(new PromotionDto(
                        resultSet.getInt("promotion_id"),
                        resultSet.getString("promotion_name"),
                        resultSet.getString("description"),
                        resultSet.getInt("voucher_id"),
                        resultSet.getInt("deal_id"),
                        resultSet.getInt("discount_id"),
                        resultSet.getString("start_date"),
                        resultSet.getString("end_date"),
                        resultSet.getString("status")
                ));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return promotions;
    }

    // Thêm hoặc cập nhật chương trình khuyến mãi
    public boolean savePromotion(PromotionDto promotion) {
        String query = (promotion.getPromotionId() != null) ?
                "UPDATE tblPromotions SET promotion_name = ?, description = ?, voucher_id = ?, deal_id = ?, discount_id = ?, start_date = ?, end_date = ?, status = ? WHERE promotion_id = ?" :
                "INSERT INTO tblPromotions (promotion_name, description, voucher_id, deal_id, discount_id, start_date, end_date, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection connection = DBUtils.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, promotion.getPromotionName());
            statement.setString(2, promotion.getDescription());
            statement.setObject(3, promotion.getVoucherId());
            statement.setObject(4, promotion.getDealId());
            statement.setObject(5, promotion.getDiscountId());
            statement.setString(6, promotion.getStartDate());
            statement.setString(7, promotion.getEndDate());
            statement.setString(8, promotion.getStatus());

            if (promotion.getPromotionId() != null) {
                statement.setInt(9, promotion.getPromotionId());
            }

            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    // Lấy chương trình khuyến mãi theo ID
    public PromotionDto getPromotionById(int promotionId) {
        String query = "SELECT * FROM tblPromotions WHERE promotion_id = ?";
        try (Connection connection = DBUtils.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, promotionId);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                return new PromotionDto(
                        resultSet.getInt("promotion_id"),
                        resultSet.getString("promotion_name"),
                        resultSet.getString("description"),
                        resultSet.getInt("voucher_id"),
                        resultSet.getInt("deal_id"),
                        resultSet.getInt("discount_id"),
                        resultSet.getString("start_date"),
                        resultSet.getString("end_date"),
                        resultSet.getString("status")
                );
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }

    // Xóa chương trình khuyến mãi
    public boolean deletePromotion(int promotionId) {
        String query = "DELETE FROM tblPromotions WHERE promotion_id = ?";

        try (Connection connection = DBUtils.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, promotionId);
            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
}
