package Model;

public class PromotionDto {
    private Integer promotionId;
    private String promotionName;
    private String description;
    private Integer voucherId;
    private Integer dealId;
    private Integer discountId;
    private String startDate;
    private String endDate;
    private String status;

    public PromotionDto() {}

    public PromotionDto(Integer promotionId, String promotionName, String description, Integer voucherId, Integer dealId, Integer discountId, String startDate, String endDate, String status) {
        this.promotionId = promotionId;
        this.promotionName = promotionName;
        this.description = description;
        this.voucherId = voucherId;
        this.dealId = dealId;
        this.discountId = discountId;
        this.startDate = startDate;
        this.endDate = endDate;
        this.status = status;
    }
    
    public Integer getDiscountId() {
        return discountId;
    }

    public void setDiscountId(Integer discountId) {
        this.discountId = discountId;
    }

    public Integer getPromotionId() {
        return promotionId;
    }

    public void setPromotionId(Integer promotionId) {
        this.promotionId = promotionId;
    }

    public String getPromotionName() {
        return promotionName;
    }

    public void setPromotionName(String promotionName) {
        this.promotionName = promotionName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getVoucherId() {
        return voucherId;
    }

    public void setVoucherId(Integer voucherId) {
        this.voucherId = voucherId;
    }

    public Integer getDealId() {
        return dealId;
    }

    public void setDealId(Integer dealId) {
        this.dealId = dealId;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
