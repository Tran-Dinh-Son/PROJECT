/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author ADMIN
 */
public class VoucherDto {
     private Integer voucherId;
    private String voucherCode;
    private String description;
    private double discountPercent;
    private String category;
    private String status;

    // Constructor
    public VoucherDto() {}

    public VoucherDto(Integer voucherId, String voucherCode, String description, double discountPercent, String category, String status) {
        this.voucherId = voucherId;
        this.voucherCode = voucherCode;
        this.description = description;
        this.discountPercent = discountPercent;
        this.category = category;
        this.status = status;
    }
    public VoucherDto(String voucherCode, String description, double discountPercent, String category, String status) {
        this.voucherCode = voucherCode;
        this.description = description;
        this.discountPercent = discountPercent;
        this.category = category;
        this.status = status;
    }

    // Getters and Setters
    public int getVoucherId() {
        return voucherId;
    }

    public void setVoucherId(int voucherId) {
        this.voucherId = voucherId;
    }

    public String getVoucherCode() {
        return voucherCode;
    }

    public void setVoucherCode(String voucherCode) {
        this.voucherCode = voucherCode;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getDiscountPercent() {
        return discountPercent;
    }

    public void setDiscountPercent(double discountPercent) {
        this.discountPercent = discountPercent;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "VoucherDto{" + "voucherId=" + voucherId + 
               ", voucherCode='" + voucherCode + '\'' + 
               ", description='" + description + '\'' + 
               ", discountPercent=" + discountPercent + 
               ", category='" + category + '\'' + 
               ", status='" + status + '\'' + '}';
    }
}
