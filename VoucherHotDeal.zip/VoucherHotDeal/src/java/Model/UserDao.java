package Model;

import Utils.DBUtils;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDao extends DBUtils {
    
    public List<UserDto> listAllUsers() {
        List<UserDto> users = new ArrayList<>();
        String query = "SELECT * FROM tblUsers";
        try (Connection connection = DBUtils.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                UserDto user = new UserDto(
                        resultSet.getString("username"),
                        resultSet.getString("name"),
                        resultSet.getString("password"),
                        resultSet.getString("role")
                );
                users.add(user);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return users;
    }

    public boolean createUser(UserDto user) {
        String query = "INSERT INTO tblUsers (username, name, password, role) VALUES (?, ?, ?, ?)";
        try (Connection connection = DBUtils.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, user.getUsername());
            statement.setString(2, user.getName());
            statement.setString(3, user.getPassword());
            statement.setString(4, user.getRole());

            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    public UserDto login(String userID, String password) {
        String query = "SELECT * FROM tblUsers WHERE username = ? AND password = ?";
        try (Connection connection = DBUtils.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, userID);
            statement.setString(2, password);

            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return new UserDto(
                        resultSet.getString("username"),
                        resultSet.getString("name"),
                        resultSet.getString("password"),
                        resultSet.getString("role")
                );
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }
    
    public boolean updateUser(UserDto user) {
        String query = "UPDATE tblUsers SET name = ?, password = ?, role = ? WHERE username = ?";
        try (Connection connection = DBUtils.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            
            statement.setString(1, user.getName());
            statement.setString(2, user.getPassword());
            statement.setString(3, user.getRole());
            statement.setString(4, user.getUsername());
            
            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
    
    public boolean deleteUser(String username) {
        String query = "DELETE FROM tblUsers WHERE username = ?";
        try (Connection connection = DBUtils.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            
            statement.setString(1, username);
            
            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
    
    public UserDto getUserByUsername(String username) {
        String query = "SELECT * FROM tblUsers WHERE username = ?";
        try (Connection connection = DBUtils.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            
            statement.setString(1, username);
            
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return new UserDto(
                        resultSet.getString("username"),
                        resultSet.getString("name"),
                        resultSet.getString("password"),
                        resultSet.getString("role")
                );
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }
    
    public static void main(String[] args) {
        UserDao userDao = new UserDao();
        
        // Test createUser
        UserDto newUser = new UserDto("testUser", "Test User", "password123", "Customer");
        boolean isCreated = userDao.createUser(newUser);
        System.out.println("Create User: " + (isCreated ? "Success" : "Failed"));
        
        // Test listAllUsers
        List<UserDto> users = userDao.listAllUsers();
        System.out.println("List of Users:");
        for (UserDto user : users) {
            System.out.println(user);
        }
        
        // Test getUserByUsername
        UserDto fetchedUser = userDao.getUserByUsername("testUser");
        System.out.println("Fetched User: " + fetchedUser);
        
        // Test updateUser
        if (fetchedUser != null) {
            fetchedUser.setName("Updated Name");
            boolean isUpdated = userDao.updateUser(fetchedUser);
            System.out.println("Update User: " + (isUpdated ? "Success" : "Failed"));
        }
        
        // Test login
        UserDto loggedInUser = userDao.login("testUser", "password123");
        System.out.println("Login Test: " + (loggedInUser != null ? "Success" : "Failed"));
        
        // Test deleteUser
//        boolean isDeleted = userDao.deleteUser("testUser");
//        System.out.println("Delete User: " + (isDeleted ? "Success" : "Failed"));
    }
}
