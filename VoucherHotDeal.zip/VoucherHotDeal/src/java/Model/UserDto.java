package Model;

public class UserDto {
    private String username;
    private String name;
    private String password;
    private String role;

    // Constructor
    public UserDto() {}

    public UserDto(String username, String name, String password, String role) {
        this.username = username;
        this.name = name;
        this.password = password;
        this.role = role;
    }

    // Getters and Setters
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    @Override
    public String toString() {
        return "UserDto{" + "username='" + username + '\'' + 
               ", name='" + name + '\'' + 
               ", role='" + role + '\'' + '}';
    }
}
