package Model;

public class DiscountCodeDto {
    private Integer discountId;
    private String code;
    private double discountPercent;
    private String status;
    private String createdBy;
    private String createdAt;

    public DiscountCodeDto() {}

    public DiscountCodeDto(Integer discountId, String code, double discountPercent, String status, String createdBy, String createdAt) {
        this.discountId = discountId;
        this.code = code;
        this.discountPercent = discountPercent;
        this.status = status;
        this.createdBy = createdBy;
        this.createdAt = createdAt;
    }

    public Integer getDiscountId() {
        return discountId;
    }

    public void setDiscountId(Integer discountId) {
        this.discountId = discountId;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public double getDiscountPercent() {
        return discountPercent;
    }

    public void setDiscountPercent(double discountPercent) {
        this.discountPercent = discountPercent;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }
}
