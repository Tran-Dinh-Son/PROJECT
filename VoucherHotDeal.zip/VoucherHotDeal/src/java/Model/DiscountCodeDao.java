package Model;

import Utils.DBUtils;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DiscountCodeDao extends DBUtils {

    // Lấy tất cả mã giảm giá
    public List<DiscountCodeDto> listAllDiscountCodes() {
        List<DiscountCodeDto> discountCodes = new ArrayList<>();
        String query = "SELECT * FROM tblDiscountCodes";

        try (Connection connection = DBUtils.getConnection();
                PreparedStatement statement = connection.prepareStatement(query);
                ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                discountCodes.add(new DiscountCodeDto(
                        resultSet.getInt("discount_id"),
                        resultSet.getString("code"),
                        resultSet.getDouble("discount_percent"),
                        resultSet.getString("status"),
                        resultSet.getString("created_by"),
                        resultSet.getString("created_at")
                ));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return discountCodes;
    }

    // Tạo hoặc cập nhật mã giảm giá
    public boolean saveDiscountCode(DiscountCodeDto discountCode) {
        String query = (discountCode.getDiscountId() != null)
                ? "UPDATE tblDiscountCodes SET code = ?, discount_percent = ?, status = ? WHERE discount_id = ?"
                : "INSERT INTO tblDiscountCodes (code, discount_percent, status, created_by) VALUES (?, ?, ?, ?)";

        try (Connection connection = DBUtils.getConnection();
                PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, discountCode.getCode());
            statement.setDouble(2, discountCode.getDiscountPercent());
            statement.setString(3, discountCode.getStatus());

            if (discountCode.getDiscountId() != null) {
                statement.setInt(4, discountCode.getDiscountId());
            } else {
                statement.setString(4, discountCode.getCreatedBy());
            }

            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    // Xóa mã giảm giá (chỉ nếu chưa sử dụng)
    public boolean deleteDiscountCode(int discountId) {
        String query = "DELETE FROM tblDiscountCodes WHERE discount_id = ?";

        try (Connection connection = DBUtils.getConnection();
                PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, discountId);
            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    // Lấy mã giảm giá theo ID
    public DiscountCodeDto getDiscountCodeById(int discountId) {
        String query = "SELECT * FROM tblDiscountCodes WHERE discount_id = ?";
        try (Connection connection = DBUtils.getConnection();
                PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, discountId);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                return new DiscountCodeDto(
                        resultSet.getInt("discount_id"),
                        resultSet.getString("code"),
                        resultSet.getDouble("discount_percent"),
                        resultSet.getString("status"),
                        resultSet.getString("created_by"),
                        resultSet.getString("created_at")
                );
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }

// Tìm kiếm mã giảm giá theo code hoặc status
    public List<DiscountCodeDto> searchDiscountCodes(String code, String status) {
        List<DiscountCodeDto> discountCodes = new ArrayList<>();
        String query = "SELECT * FROM tblDiscountCodes WHERE 1=1";
        List<String> params = new ArrayList<>();

        if (code != null && !code.isEmpty()) {
            query += " AND code LIKE ?";
            params.add("%" + code + "%");
        }
        if (status != null && !status.isEmpty()) {
            query += " AND status = ?";
            params.add(status);
        }

        try (Connection connection = DBUtils.getConnection();
                PreparedStatement statement = connection.prepareStatement(query)) {

            for (int i = 0; i < params.size(); i++) {
                statement.setString(i + 1, params.get(i));
            }

            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                discountCodes.add(new DiscountCodeDto(
                        resultSet.getInt("discount_id"),
                        resultSet.getString("code"),
                        resultSet.getDouble("discount_percent"),
                        resultSet.getString("status"),
                        resultSet.getString("created_by"),
                        resultSet.getString("created_at")
                ));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return discountCodes;
    }

}
