package Model;

import Utils.DBUtils;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class VoucherDao extends DBUtils {

    // Search Vouchers by Category or Status
    public List<VoucherDto> searchVouchers(String category, String status) {
        List<VoucherDto> vouchers = new ArrayList<>();

        // Xây dựng SQL động dựa trên tham số đầu vào
        String query = "SELECT * FROM tblVouchers WHERE 1=1"; // Luôn đúng để dễ nối điều kiện

        // Danh sách các tham số
        List<String> params = new ArrayList<>();

        if (category != null && !category.isEmpty()) {
            query += " AND Category = ?";
            params.add(category);
        }
        if (status != null && !status.isEmpty()) {
            query += " AND Status = ?";
            params.add(status);
        }

        try (Connection connection = DBUtils.getConnection();
                PreparedStatement statement = connection.prepareStatement(query)) {

            // Set tham số vào câu lệnh SQL
            for (int i = 0; i < params.size(); i++) {
                statement.setString(i + 1, params.get(i));
            }

            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                vouchers.add(new VoucherDto(
                        resultSet.getInt("voucher_id"),
                        resultSet.getString("voucher_code"),
                        resultSet.getString("Description"),
                        resultSet.getDouble("discount_percent"),
                        resultSet.getString("Category"),
                        resultSet.getString("Status")
                ));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return vouchers;
    }

    // Create or Update Voucher
    public boolean saveVoucher(VoucherDto voucher) {
        String query = voucher.getVoucherId() > 0
                ? "UPDATE tblVouchers SET voucher_code = ?, Description = ?, discount_percent = ?, Category = ?, Status = ? WHERE voucher_id = ?"
                : "INSERT INTO tblVouchers (voucher_code, Description, discount_percent, Category, Status) VALUES (?, ?, ?, ?, ?)";

        try (Connection connection = DBUtils.getConnection();
                PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, voucher.getVoucherCode());
            statement.setString(2, voucher.getDescription());
            statement.setDouble(3, voucher.getDiscountPercent());
            statement.setString(4, voucher.getCategory());
            statement.setString(5, voucher.getStatus());

            if (voucher.getVoucherId() > 0) {
                statement.setInt(6, voucher.getVoucherId());
            }

            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    // Change Status to Inactive
    public boolean setInactive(int voucherId) {
        String query = "UPDATE tblVouchers SET Status = 'Inactive' WHERE voucher_id = ?";
        try (Connection connection = DBUtils.getConnection();
                PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, voucherId);
            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    // List all Vouchers
    public List<VoucherDto> listAllVouchers() {
        List<VoucherDto> vouchers = new ArrayList<>();
        String query = "SELECT * FROM tblVouchers";
        try (Connection connection = DBUtils.getConnection();
                PreparedStatement statement = connection.prepareStatement(query);
                ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                vouchers.add(new VoucherDto(
                        resultSet.getInt("voucher_id"),
                        resultSet.getString("voucher_code"),
                        resultSet.getString("Description"),
                        resultSet.getDouble("discount_percent"),
                        resultSet.getString("Category"),
                        resultSet.getString("Status")
                ));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return vouchers;
    }

    // Get Voucher by ID
    public VoucherDto getVoucherById(int voucherId) {
        String query = "SELECT * FROM tblVouchers WHERE voucher_id = ?";
        try (Connection connection = DBUtils.getConnection();
                PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, voucherId);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                return new VoucherDto(
                        resultSet.getInt("voucher_id"),
                        resultSet.getString("voucher_code"),
                        resultSet.getString("Description"),
                        resultSet.getDouble("discount_percent"),
                        resultSet.getString("Category"),
                        resultSet.getString("Status")
                );
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }

    // Delete Voucher
    public boolean deleteVoucher(int voucherId) {
        String query = "DELETE FROM tblVouchers WHERE voucher_id = ?";
        try (Connection connection = DBUtils.getConnection();
                PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, voucherId);
            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }
}
