﻿CREATE DATABASE VoucherHotDealDB;
GO

USE VoucherHotDealDB;
GO

-- Tạo bảng Users
CREATE TABLE tblUsers (
    username NVARCHAR(50) PRIMARY KEY,
    name NVARCHAR(100) NOT NULL,
    password NVARCHAR(255) NOT NULL,
    role NVARCHAR(20) NOT NULL CHECK (role IN ('Admin', 'Customer'))
);
GO

-- Tạo bảng Vouchers
CREATE TABLE tblVouchers (
    voucher_id INT IDENTITY(1,1) PRIMARY KEY,
    voucher_code NVARCHAR(20) UNIQUE NOT NULL,
    Description NVARCHAR(MAX) NULL,
    discount_percent DECIMAL(5,2) NOT NULL,
    Category NVARCHAR(50) NOT NULL,
    Status NVARCHAR(20) NOT NULL CHECK (Status IN ('Active', 'Inactive', 'Expired'))
);
GO

-- Tạo bảng Hot Deals
CREATE TABLE tblHotDeals (
    deal_id INT IDENTITY(1,1) PRIMARY KEY,
    deal_name NVARCHAR(100) NOT NULL,
    Description NVARCHAR(MAX) NULL,
    discount_amount DECIMAL(10,2) NOT NULL,
    Category NVARCHAR(50) NOT NULL,
    Status NVARCHAR(20) NOT NULL CHECK (Status IN ('Active', 'Inactive', 'Expired')),
    expiration_date DATE NOT NULL
);
GO

-- Insert dữ liệu vào bảng Users
INSERT INTO tblUsers (username, name, password, role) VALUES
('admin1', 'Admin User', 'admin123', 'Admin'),
('customer1', 'Customer User', 'customer123', 'Customer');
GO

-- Insert dữ liệu vào bảng Vouchers
INSERT INTO tblVouchers (voucher_code, Description, discount_percent, Category, Status) VALUES
('FASHION10', '10% off on Fashion', 10.00, 'Fashion', 'Active'),
('ELEC15', '15% off on Electronics', 15.00, 'Electronics', 'Active'),
('HOME20', '20% off on Home Items', 20.00, 'Home', 'Inactive');
GO

-- Insert dữ liệu vào bảng Hot Deals
INSERT INTO tblHotDeals (deal_name, Description, discount_amount, Category, Status, expiration_date) VALUES
('Black Friday Sale', 'Massive discounts on all items', 50.00, 'Fashion', 'Active', '2025-11-29'),
('New Year Offer', 'Special discounts for New Year', 30.00, 'Electronics', 'Active', '2025-01-01'),
('Summer Special', 'Seasonal discount for home appliances', 25.00, 'Home', 'Inactive', '2025-06-15');
GO