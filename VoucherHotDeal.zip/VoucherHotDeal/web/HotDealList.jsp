<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Hot Deal List</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    </head>
    <body class="container mt-4">
        <h2 class="text-center mb-4">Hot Deal List</h2>

        <form action="HotDealController" method="GET" class="row g-3 mb-4">
            <input type="hidden" name="action" value="search">
            
            <div class="col-md-4">
                <label for="category" class="form-label">Category:</label>
                <input type="text" id="category" name="category" class="form-control">
            </div>

            <div class="col-md-4">
                <label for="status" class="form-label">Status:</label>
                <select id="status" name="status" class="form-select">
                    <option value="">All</option>
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                    <option value="Expired">Expired</option>
                </select>
            </div>
            
            <div class="col-md-4 d-flex align-items-end">
                <button type="submit" class="btn btn-primary w-100">Search</button>
            </div>
        </form>

        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr>
                    <th>Deal Name</th>
                    <th>Description</th>
                    <th>Discount Amount</th>
                    <th>Category</th>
                    <th>Status</th>
                    <th>Expiration Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <c:forEach var="hotDeal" items="${requestScope.hotDeals}">
                    <tr>
                        <td>${hotDeal.dealName}</td>
                        <td>${hotDeal.description}</td>
                        <td>${hotDeal.discountAmount}</td>
                        <td>${hotDeal.category}</td>
                        <td>${hotDeal.status}</td>
                        <td>${hotDeal.expirationDate}</td>
                        <td>
                            <c:if test="${sessionScope.role == 'Admin'}">
                                <a href="HotDealController?action=getById&dealId=${hotDeal.dealId}" class="btn btn-sm btn-warning">Edit</a>
                                <a href="HotDealController?action=changeStatus&dealId=${hotDeal.dealId}" class="btn btn-sm btn-danger">Set Inactive</a>
                            </c:if>
                        </td>
                    </tr>
                </c:forEach>
            </tbody>
        </table>

        <div class="d-flex justify-content-between mt-4">
            <c:if test="${sessionScope.role == 'Admin'}">
                <a href="HotDealForm.jsp" class="btn btn-success">Create New Hot Deal</a>
            </c:if>
            <form action="LogoutController" method="POST">
                <button type="submit" class="btn btn-secondary">Logout</button>
            </form>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    </body>
</html>