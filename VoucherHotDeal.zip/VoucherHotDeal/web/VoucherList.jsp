<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Voucher List</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    </head>
    <body class="container mt-4">
        <h2 class="text-center mb-4">Voucher List</h2>

        <form action="VoucherController" method="GET" class="row g-3 mb-4">
            <input type="hidden" name="action" value="search">
            
            <div class="col-md-4">
                <label for="category" class="form-label">Category:</label>
                <input type="text" id="category" name="category" class="form-control">
            </div>

            <div class="col-md-4">
                <label for="status" class="form-label">Status:</label>
                <select id="status" name="status" class="form-select">
                    <option value="">All</option>
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                    <option value="Expired">Expired</option>
                </select>
            </div>
            
            <div class="col-md-4 d-flex align-items-end">
                <button type="submit" class="btn btn-primary w-100">Search</button>
            </div>
        </form>

        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr>
                    <th>Voucher Code</th>
                    <th>Description</th>
                    <th>Discount (%)</th>
                    <th>Category</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <c:forEach var="voucher" items="${requestScope.vouchers}">
                    <tr>
                        <td>${voucher.voucherCode}</td>
                        <td>${voucher.description}</td>
                        <td>${voucher.discountPercent}</td>
                        <td>${voucher.category}</td>
                        <td>${voucher.status}</td>
                        <td>
                            <c:if test="${sessionScope.role == 'Admin'}">
                                <a href="VoucherController?action=getById&voucherId=${voucher.voucherId}" class="btn btn-sm btn-warning">Edit</a>
                                <a href="VoucherController?action=changeStatus&voucherId=${voucher.voucherId}" class="btn btn-sm btn-danger">Set Inactive</a>
                            </c:if>
                        </td>
                    </tr>
                </c:forEach>
            </tbody>
        </table>

        <div class="d-flex justify-content-between mt-4">
            <c:if test="${sessionScope.role == 'Admin'}">
                <a href="VoucherForm.jsp" class="btn btn-success">Create New Voucher</a>
            </c:if>
            <form action="LogoutController" method="POST">
                <button type="submit" class="btn btn-secondary">Logout</button>
            </form>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    </body>
</html>