<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Discount Code List</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #f4f4f4;
                margin: 0;
                padding: 20px;
            }
            .container {
                max-width: 800px;
                margin: auto;
                background: white;
                padding: 20px;
                border-radius: 8px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            }
            h2 {
                text-align: center;
                color: #333;
            }
            form {
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
                gap: 10px;
                margin-bottom: 20px;
            }
            input[type="text"], select {
                padding: 8px;
                border: 1px solid #ccc;
                border-radius: 5px;
            }
            input[type="submit"] {
                background: #28a745;
                color: white;
                border: none;
                padding: 8px 15px;
                border-radius: 5px;
                cursor: pointer;
            }
            table {
                width: 100%;
                border-collapse: collapse;
                background: white;
            }
            th, td {
                padding: 10px;
                border: 1px solid #ddd;
                text-align: center;
            }
            th {
                background: #007bff;
                color: white;
            }
            a {
                text-decoration: none;
                padding: 5px 10px;
                border-radius: 5px;
            }
            .edit {
                background: #ffc107;
                color: white;
            }
            .delete {
                background: #dc3545;
                color: white;
            }
            .create-btn {
                display: block;
                width: max-content;
                margin: 20px auto;
                background: #17a2b8;
                color: white;
                padding: 10px 15px;
                border-radius: 5px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h2>Discount Code List</h2>
            
            <form action="DiscountCodeController" method="GET">
                <input type="hidden" name="action" value="search">
                <input type="text" id="code" name="code" placeholder="Enter code">
                <select id="status" name="status">
                    <option value="">All</option>
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                    <option value="Expired">Expired</option>
                </select>
                <input type="submit" value="Search">
            </form>

            <table>
                <tr>
                    <th>Code</th>
                    <th>Discount (%)</th>
                    <th>Status</th>
                    <th>Created By</th>
                    <th>Created At</th>
                    <th>Actions</th>
                </tr>
                <c:forEach var="discountCode" items="${requestScope.discountCodes}">
                    <tr>
                        <td>${discountCode.code}</td>
                        <td>${discountCode.discountPercent}</td>
                        <td>${discountCode.status}</td>
                        <td>${discountCode.createdBy}</td>
                        <td>${discountCode.createdAt}</td>
                        <td>
                            <c:if test="${sessionScope.role == 'Admin'}">
                                <a href="DiscountCodeController?action=getById&discountId=${discountCode.discountId}" class="edit">Edit</a>
                                <a href="DiscountCodeController?action=delete&discountId=${discountCode.discountId}" class="delete">Delete</a>
                            </c:if>
                        </td>
                    </tr>
                </c:forEach>
            </table>

            <c:if test="${sessionScope.role == 'Admin'}">
                <a href="DiscountCodeForm.jsp" class="create-btn">Create New Discount Code</a>
            </c:if>
        </div>
    </body>
</html>
