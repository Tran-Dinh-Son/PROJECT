<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Voucher Form</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    </head>
    <body class="container mt-5">
        <h2 class="text-center mb-4">${voucher.voucherId == null ? "Create New Voucher" : "Edit Voucher"}</h2>
        
        <form action="VoucherController" method="POST" class="p-4 border rounded bg-light">
            <input type="hidden" name="action" value="createOrUpdate">
            <input type="hidden" name="voucherId" value="${voucher.voucherId}">
            
            <div class="mb-3">
                <label for="voucherCode" class="form-label">Voucher Code:</label>
                <input type="text" id="voucherCode" name="voucherCode" value="${voucher.voucherCode}" class="form-control" required>
            </div>
            
            <div class="mb-3">
                <label for="description" class="form-label">Description:</label>
                <input type="text" id="description" name="description" value="${voucher.description}" class="form-control">
            </div>
            
            <div class="mb-3">
                <label for="discountPercent" class="form-label">Discount (%):</label>
                <input type="number" id="discountPercent" name="discountPercent" value="${voucher.discountPercent}" class="form-control" required>
            </div>
            
            <div class="mb-3">
                <label for="category" class="form-label">Category:</label>
                <input type="text" id="category" name="category" value="${voucher.category}" class="form-control" required>
            </div>
            
            <div class="mb-3">
                <label for="status" class="form-label">Status:</label>
                <select id="status" name="status" class="form-select">
                    <option value="Active" ${voucher.status == 'Active' ? 'selected' : ''}>Active</option>
                    <option value="Inactive" ${voucher.status == 'Inactive' ? 'selected' : ''}>Inactive</option>
                    <option value="Expired" ${voucher.status == 'Expired' ? 'selected' : ''}>Expired</option>
                </select>
            </div>
            
            <button type="submit" class="btn btn-primary w-100">Save</button>
        </form>
        
        <div class="text-center mt-3">
            <a href="VoucherController?action=list" class="btn btn-secondary">Back to Voucher List</a>
        </div>
        
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    </body>
</html>
