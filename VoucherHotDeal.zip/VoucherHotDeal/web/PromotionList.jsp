<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Promotion List</title>
    </head>
    <body>
        <h2>Promotion List</h2>
        <form action="PromotionController" method="GET">
            <input type="hidden" name="action" value="search">

            <label for="promotionName">Promotion Name:</label>
            <input type="text" id="promotionName" name="promotionName">

            <label for="status">Status:</label>
            <select id="status" name="status">
                <option value="">All</option>
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
                <option value="Expired">Expired</option>
            </select>

            <label for="voucherId">Voucher ID:</label>
            <input type="number" id="voucherId" name="voucherId">

            <label for="dealId">Deal ID:</label>
            <input type="number" id="dealId" name="dealId">
            
            <label for="discountId">Discount ID:</label>
            <input type="number" id="discountId" name="discountId">
            
            <input type="submit" value="Search">
        </form>

        <table border="1">
            <tr>
                <th>Promotion Name</th>
                <th>Description</th>
                <th>Voucher ID</th>
                <th>Deal ID</th>
                <th>Discount ID</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
            <c:forEach var="promotion" items="${requestScope.promotions}">
                <tr>
                    <td>${promotion.promotionName}</td>
                    <td>${promotion.description}</td>
                    <td>${promotion.voucherId}</td>
                    <td>${promotion.dealId}</td>
                    <td>${promotion.discountId}</td>
                    <td>${promotion.startDate}</td>
                    <td>${promotion.endDate}</td>
                    <td>${promotion.status}</td>
                    <td>
                        <c:if test="${sessionScope.role == 'Admin'}">
                            <a href="PromotionController?action=getById&promotionId=${promotion.promotionId}">Edit</a> |
                            <a href="PromotionController?action=delete&promotionId=${promotion.promotionId}" onclick="return confirm('Are you sure?');">Delete</a>
                        </c:if>
                    </td>
                </tr>
            </c:forEach>
        </table>

        <br>
        <a href="PromotionForm.jsp">Create New Promotion</a>
    </body>
</html>