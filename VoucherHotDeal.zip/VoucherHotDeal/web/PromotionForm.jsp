<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Promotion Form</title>
    </head>
    <body>
        <h2>${promotion.promotionId == null ? "Create New Promotion" : "Edit Promotion"}</h2>
        
        <form action="PromotionController" method="POST">
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="promotionId" value="${promotion.promotionId}">
            
            <label for="promotionName">Promotion Name:</label>
            <input type="text" id="promotionName" name="promotionName" value="${promotion.promotionName}" required>
            <br>
            
            <label for="description">Description:</label>
            <textarea id="description" name="description">${promotion.description}</textarea>
            <br>
            
            <label for="voucherId">Voucher ID:</label>
            <input type="number" id="voucherId" name="voucherId" value="${promotion.voucherId}">
            <br>
            
            <label for="dealId">Deal ID:</label>
            <input type="number" id="dealId" name="dealId" value="${promotion.dealId}">
            <br>
            
            <label for="discountId">Discount ID:</label>
            <input type="number" id="discountId" name="discountId" value="${promotion.discountId}">
            <br>
            
            <label for="startDate">Start Date:</label>
            <input type="date" id="startDate" name="startDate" value="${promotion.startDate}" required>
            <br>
            
            <label for="endDate">End Date:</label>
            <input type="date" id="endDate" name="endDate" value="${promotion.endDate}" required>
            <br>
            
            <label for="status">Status:</label>
            <select id="status" name="status">
                <option value="Active" ${promotion.status == 'Active' ? 'selected' : ''}>Active</option>
                <option value="Inactive" ${promotion.status == 'Inactive' ? 'selected' : ''}>Inactive</option>
                <option value="Expired" ${promotion.status == 'Expired' ? 'selected' : ''}>Expired</option>
            </select>
            <br>
            
            <input type="submit" value="Save">
        </form>
        
        <br>
        <a href="PromotionController?action=list">Back to Promotion List</a>
    </body>
</html>