<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Hot Deal Form</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    </head>
    <body class="container mt-5">
        <h2 class="text-center mb-4">${hotDeal.dealId == null ? "Create New Hot Deal" : "Edit Hot Deal"}</h2>
        
        <form action="HotDealController" method="POST" class="p-4 border rounded bg-light">
            <input type="hidden" name="action" value="createOrUpdate">
            <input type="hidden" name="dealId" value="${hotDeal.dealId}">
            
            <div class="mb-3">
                <label for="dealName" class="form-label">Deal Name:</label>
                <input type="text" id="dealName" name="dealName" value="${hotDeal.dealName}" class="form-control" required>
            </div>
            
            <div class="mb-3">
                <label for="description" class="form-label">Description:</label>
                <input type="text" id="description" name="description" value="${hotDeal.description}" class="form-control">
            </div>
            
            <div class="mb-3">
                <label for="discountAmount" class="form-label">Discount Amount:</label>
                <input type="number" id="discountAmount" name="discountAmount" value="${hotDeal.discountAmount}" class="form-control" required>
            </div>
            
            <div class="mb-3">
                <label for="category" class="form-label">Category:</label>
                <input type="text" id="category" name="category" value="${hotDeal.category}" class="form-control" required>
            </div>
            
            <div class="mb-3">
                <label for="status" class="form-label">Status:</label>
                <select id="status" name="status" class="form-select">
                    <option value="Active" ${hotDeal.status == 'Active' ? 'selected' : ''}>Active</option>
                    <option value="Inactive" ${hotDeal.status == 'Inactive' ? 'selected' : ''}>Inactive</option>
                    <option value="Expired" ${hotDeal.status == 'Expired' ? 'selected' : ''}>Expired</option>
                </select>
            </div>
            
            <div class="mb-3">
                <label for="expirationDate" class="form-label">Expiration Date:</label>
                <input type="date" id="expirationDate" name="expirationDate" value="${hotDeal.expirationDate}" class="form-control" required>
            </div>
            
            <button type="submit" class="btn btn-primary w-100">Save</button>
        </form>
        
        <div class="text-center mt-3">
            <a href="HotDealController?action=list" class="btn btn-secondary">Back to Hot Deal List</a>
        </div>
        
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    </body>
</html>