<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voucher & Hotdeal Admin - Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
</head>
<body class="container mt-5">
    <div class="card p-4 shadow-lg">
        <h2 class="text-center">Welcome, ${sessionScope.username}!</h2>
        
        <h3 class="mt-4">Manage Promotions</h3>
        <ul class="list-group">
            <li class="list-group-item"><a href="PromotionController?action=list" class="text-decoration-none">Manage Promotions</a></li>
            <li class="list-group-item"><a href="VoucherController?action=list" class="text-decoration-none">Manage Vouchers</a></li>
            <li class="list-group-item"><a href="HotDealController?action=list" class="text-decoration-none">Manage Hot Deals</a></li>
            <li class="list-group-item"><a href="DiscountCodeController?action=list" class="text-decoration-none">Manage Discount Codes</a></li>
        </ul>
        
        <br>
        <form action="LogoutController" method="POST" class="text-center">
            <button type="submit" class="btn btn-danger">Logout</button>
        </form>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>
</html>