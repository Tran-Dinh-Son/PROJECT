<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>${discountCode.discountId == null ? "Create New Discount Code" : "Edit Discount Code"}</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #f4f4f4;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
            }
            .container {
                background: white;
                padding: 20px;
                border-radius: 8px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                width: 400px;
                text-align: center;
            }
            h2 {
                color: #333;
                margin-bottom: 20px;
            }
            form {
                display: flex;
                flex-direction: column;
                gap: 10px;
            }
            label {
                text-align: left;
                font-weight: bold;
            }
            input, select {
                width: 100%;
                padding: 8px;
                border: 1px solid #ccc;
                border-radius: 5px;
            }
            input[type="submit"] {
                background: #28a745;
                color: white;
                border: none;
                padding: 10px;
                cursor: pointer;
                font-size: 16px;
            }
            input[type="submit"]:hover {
                background: #218838;
            }
            .back-btn {
                display: block;
                margin-top: 15px;
                background: #007bff;
                color: white;
                padding: 10px;
                border-radius: 5px;
                text-decoration: none;
                text-align: center;
            }
            .back-btn:hover {
                background: #0056b3;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h2>${discountCode.discountId == null ? "Create New Discount Code" : "Edit Discount Code"}</h2>
            
            <form action="DiscountCodeController" method="POST">
                <input type="hidden" name="action" value="createOrUpdate">
                <input type="hidden" name="discountId" value="${discountCode.discountId}">
                
                <label for="code">Code:</label>
                <input type="text" id="code" name="code" value="${discountCode.code}" required>
                
                <label for="discountPercent">Discount (%):</label>
                <input type="number" id="discountPercent" name="discountPercent" value="${discountCode.discountPercent}" required>
                
                <label for="status">Status:</label>
                <select id="status" name="status">
                    <option value="Active" ${discountCode.status == 'Active' ? 'selected' : ''}>Active</option>
                    <option value="Inactive" ${discountCode.status == 'Inactive' ? 'selected' : ''}>Inactive</option>
                    <option value="Expired" ${discountCode.status == 'Expired' ? 'selected' : ''}>Expired</option>
                </select>
                
                <input type="submit" value="Save">
            </form>
            
            <a href="DiscountCodeController?action=list" class="back-btn">Back to Discount Code List</a>
        </div>
    </body>
</html>
